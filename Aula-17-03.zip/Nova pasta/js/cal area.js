function quadrado () {
    let n1 = parseFloat(document.getElementById("num1").value);
    let n2 = parseFloat(document.getElementById("num2").value);
    let area = n1 * n2;
    document.getElementById("resultado").innerHTML = `Area: ${area}`
}
function retangulo (){
    let n1 = parseFloat(document.getElementById("num1").value);
    let n2 = parseFloat(document.getElementById("num2").value);
    let area = n1 * n2 ;
    document.getElementById("resultado").innerHTML = `Area: ${area}`;
}

function triangulo () {
    let n1 = parseFloat(document.getElementById("num1").value);
    let n2 = parseFloat(document.getElementById("num2").value);
    let area = (n1 * n2) / 2 ;
    document.getElementById("resultado").innerHTML = `Area: ${area}`;
}

function circulo () {
    let n1 = parseFloat(document.getElementById("num1").value);
    let raio = n1 / 2 ;
    let cal = raio * raio ;
    let area = cal * 3.14 ;
    document.getElementById("resultado").innerHTML = `Area: ${area}`;
}